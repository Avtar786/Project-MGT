const Strings = {
  signUpData: 'SignUpData',
  success: 'Success',
  userAddedSignUp: 'User Added Successfully!',
  tasks: 'Tasks',
};
export default Strings;
